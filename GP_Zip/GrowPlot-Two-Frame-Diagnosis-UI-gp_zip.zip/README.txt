GrowPlot two-frame diagnosis UI patch. Apply to current GitHub main checkout: python3 apply_patch.py /path/to/GrowPlot-New
Click Run diagnosis opens a new modal with original photo and CV result frame. UI ONLY: no CV inference, counting, or pixel analysis is triggered yet, per requested first step. Commit index.html and run Android build.
