
from pathlib import Path
import sys
repo=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd()
index=repo/'app/src/main/assets/index.html'
if not index.exists(): raise SystemExit('STOP: GrowPlot index.html not found')
html=index.read_text(encoding='utf-8')
needle='async function runDiagnosisScreen(camera){'
if 'function showGrowPlotCVWindow(camera)' not in html:
    insertion="""function showGrowPlotCVWindow(camera){
 const saved=diagnosisMediaFor(camera);
 const photo=saved.filter(item=>item.kind==='photo'&&item.url).slice(-1)[0];
 let modal=document.getElementById('growplotCVWindow');
 if(!modal){
  modal=document.createElement('div');
  modal.id='growplotCVWindow';
  modal.setAttribute('role','dialog');
  modal.setAttribute('aria-modal','true');
  modal.setAttribute('aria-label','Plant CV diagnosis');
  modal.style.cssText='position:fixed;inset:0;z-index:2147483000;background:rgba(0,0,0,.7);display:flex;align-items:center;justify-content:center;padding:12px';
  modal.innerHTML='<div style="background:#fff;color:#1b3627;border-radius:14px;width:min(960px,100%);max-height:92vh;overflow:auto;padding:16px"><div style="display:flex;justify-content:space-between;align-items:center;gap:12px"><h3 id="growplotCVTitle" style="margin:0">Plant CV diagnosis</h3><button id="growplotCVClose" type="button" style="padding:8px 14px">Close</button></div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,280px),1fr));gap:14px;margin-top:16px"><section style="border:1px solid #d6e2d9;border-radius:10px;padding:12px"><h4>1. Original plant photograph</h4><img id="growplotCVOriginal" alt="Original plant photograph" style="width:100%;max-height:65vh;object-fit:contain;background:#eef3ef;border-radius:8px"><p id="growplotCVPhotoStatus"></p></section><section style="border:1px solid #d6e2d9;border-radius:10px;padding:12px"><h4>2. CV diagnosis</h4><div id="growplotCVResults" style="min-height:220px;display:flex;align-items:center;justify-content:center;background:#f4f8f5;border-radius:8px;padding:18px;text-align:center">CV analysis output will appear in this frame. No analysis is run in this UI-only change.</div></section></div></div>';
  document.body.appendChild(modal);
  modal.querySelector('#growplotCVClose').onclick=()=>{modal.style.display='none'};
  modal.addEventListener('click',e=>{if(e.target===modal)modal.style.display='none'});
 }
 modal.style.display='flex';
 modal.querySelector('#growplotCVTitle').textContent='CCTV '+String(camera).padStart(2,'0')+' — Plant CV diagnosis';
 const image=modal.querySelector('#growplotCVOriginal');
 const status=modal.querySelector('#growplotCVPhotoStatus');
 if(photo){image.hidden=false;image.src=photo.url;status.textContent='Latest selected section photograph'}
 else{image.hidden=true;image.removeAttribute('src');status.textContent='No photograph available for this CCTV section.'}
}
"""
    if needle not in html: raise SystemExit('STOP: diagnosis function not found')
    html=html.replace(needle,insertion+needle,1)
# UI-only request: open new window immediately and skip old analysis.
call='async function runDiagnosisScreen(camera){showGrowPlotCVWindow(camera);return;'
if call not in html:
    if needle not in html: raise SystemExit('STOP: diagnosis function not found after insertion')
    html=html.replace(needle,call,1)
index.write_text(html,encoding='utf-8')
print('Installed new two-frame CV diagnosis window; original pixel diagnosis remains in source but is not triggered.')
