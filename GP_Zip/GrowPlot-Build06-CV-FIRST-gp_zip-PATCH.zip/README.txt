GrowPlot Build 06 CV-first diagnosis correction
=============================================
PATCH ZIP — NOT an APK and NOT the full repository.
Use against CURRENT GitHub main source, without replacing other files.

Changes:
- Existing Run diagnosis calls CV analysis directly and awaits it BEFORE pixel screening.
- CV report appears inside result section BEFORE the old colour-pixel report.
- No duplicate CV button and no unreliable click/MutationObserver trigger.
- The annotated result labels candidate foliage regions, NOT verified individual leaves.
- Existing species and provider integrations are unchanged; unavailable APIs remain unavailable.

Merge:
  python3 apply_patch.py /path/to/GrowPlot-New
  git add app/src/main/assets/index.html app/src/main/assets/leaf-cv.js
  git commit -m "fix: invoke CV before pixel diagnosis and render results first"
  git push

Then GitHub Actions android-arm64-build.yml should run automatically.
Do not replace entire source tree with this patch ZIP.
