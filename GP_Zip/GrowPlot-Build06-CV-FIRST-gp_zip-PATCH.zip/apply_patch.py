#!/usr/bin/env python3
"""Apply Build 06 CV direct-flow fix to current GrowPlot source checkout."""
from pathlib import Path
import sys, shutil
repo=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd()
index=repo/'app/src/main/assets/index.html'
cv=repo/'app/src/main/assets/leaf-cv.js'
if not index.is_file() or not cv.is_file():
    raise SystemExit('STOP: Not a GrowPlot source checkout')
s=index.read_text(encoding='utf-8')
needle="if(button)button.disabled=true;if(status)status.textContent='Analyzing quadrant photos on this device…';"
replacement="""if(button)button.disabled=true;
if(status)status.textContent='Running foliage CV analysis…';
if(window.GrowPlotCV&&typeof window.GrowPlotCV.analyze==='function'){
 try{await window.GrowPlotCV.analyze(camera)}
 catch(cvError){const cvBox=document.getElementById('cvLeafPanel');if(cvBox)cvBox.insertAdjacentHTML('beforeend','<p>CV analysis error: '+escapeDiagnosisText(cvError.message||cvError)+'</p>')}
}
if(status)status.textContent='Running colour-pixel screening…';"""
if needle not in s:
    if 'await window.GrowPlotCV.analyze(camera)' in s:
        print('Index already patched; checking CV module.')
    else:
        raise SystemExit('STOP: Run diagnosis function differs; manual review required')
else:
    s=s.replace(needle,replacement,1)
    index.write_text(s,encoding='utf-8')
shutil.copy2(Path(__file__).resolve().parent/'app/src/main/assets/leaf-cv.js',cv)
print('Applied CV-first flow and explicit API; original pixel screening retained.')
