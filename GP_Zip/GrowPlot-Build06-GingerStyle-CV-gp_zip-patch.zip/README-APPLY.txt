GrowPlot ginger-style CV enhancement — Build 06 patch (NOT complete source)
Baseline: GitHub main v0.7.00 Build 05 (versionCode 218).

1. Copy app/src/main/assets/leaf-cv.js into the same path in the repository.
2. In app/src/main/assets/index.html insert <script src="leaf-cv.js"></script> immediately before </body> if not already present.
3. Ensure existing renderDiagnosisModal(camera) and diagnosisMediaFor(camera) functions are exposed on window. The module wraps renderDiagnosisModal to add a per-section analysis panel.
4. Update version.properties to versionName=0.7.00 Build 06 and versionCode=219 only after merging with current GitHub main.
5. Commit and run existing ARM64 GitHub Actions build; use existing permanent signing secrets. Verify diagnosis on Android with actual plant images and confirm no regression to CCTV/Drive.

Added: annotated candidate foliage-region boxes and numbers, cropped thumbnails for each numbered region, green/yellow/brown per-region percentages, explanations and checks, growth/age/flowering limitations, local per-plot/per-section summary.
IMPORTANT: this is deterministic colour-region segmentation, NOT validated individual leaf instance segmentation, species recognition, confirmed disease diagnosis, accurate leaf maturity classification or actual planting-age prediction. Overlapping leaves, background and lighting may skew results. The output intentionally labels 'region' rather than 'leaf'. No fake count or disease claims.
No credentials or keystore included. Patch ZIP should be MERGED, not used as a replacement full project archive.
