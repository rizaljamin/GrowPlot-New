#!/usr/bin/env python3
"""Merge the ginger-style CV patch into an existing GrowPlot checkout."""
from pathlib import Path
import shutil, sys
repo=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd()
assets=repo/'app/src/main/assets'
index=assets/'index.html'
source=Path(__file__).resolve().parent/'app/src/main/assets/leaf-cv.js'
if not index.is_file() or not (repo/'version.properties').is_file():
    raise SystemExit('ERROR: Run against the root of the current GrowPlot repository.')
html=index.read_text(encoding='utf-8')
script='<script src="leaf-cv.js"></script>'
if script not in html:
    if '</body>' not in html: raise SystemExit('ERROR: </body> not found.')
    html=html.replace('</body>',script+'\n</body>',1)
    index.write_text(html,encoding='utf-8')
shutil.copy2(source,assets/'leaf-cv.js')
version=repo/'version.properties'
v=version.read_text()
import re
m=re.search(r'^versionCode=(\d+)$',v,re.M)
if not m: raise SystemExit('ERROR: Missing versionCode')
code=int(m.group(1))
if code>219: raise SystemExit('ERROR: Repository already newer than Build 06; refusing downgrade.')
v=re.sub(r'^versionName=.*$', 'versionName=0.7.00 Build 06',v,flags=re.M)
v=re.sub(r'^versionCode=.*$', 'versionCode=219',v,flags=re.M)
version.write_text(v)
print('Applied CV module + diagnosis integration; set Build 06 versionCode 219.')
