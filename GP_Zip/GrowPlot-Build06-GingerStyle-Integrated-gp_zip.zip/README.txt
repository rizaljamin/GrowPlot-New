GrowPlot v0.7.00 Build 06 ginger-style CV integration patch
=============================================================
This is a merge patch for the CURRENT GitHub main checkout (Build 05), not a full Android project.
It does not replace index.html or other working modules.

1. Extract ZIP to a temporary folder.
2. From GitHub repository root run:
   python3 /path/to/extracted/apply_patch.py /path/to/GrowPlot-New
3. Commit the changed files: app/src/main/assets/index.html,
   app/src/main/assets/leaf-cv.js, version.properties.
4. Run GitHub Actions ARM64 build with the existing stable signing secrets.

The integration automatically runs foliage annotation after the existing photo
diagnosis function finishes, and also offers an Analyze latest photo button.
Existing CCTV, Google Drive and PlantNet functions are left untouched.

This module identifies candidate foliage regions, NOT verified leaf instances.
No scientifically validated disease identification or leaf maturity prediction.
Android runtime and signing have NOT been verified.
